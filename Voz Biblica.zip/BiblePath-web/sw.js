// Voz Bíblica — guardado offline.
// La PÁGINA se pide siempre a la red, con la copia guardada como respaldo si no
// hay internet: así una versión nueva se ve en la primera recarga, no en la
// segunda. Los assets (imágenes, iconos) sí van desde la copia guardada, que es
// lo que hace que la app abra rápido.
const CACHE = 'vozbiblica-v6';

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  const esPagina = req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html');
  const clave = esPagina ? './' : req;

  const desdeRed = () => fetch(req).then(r => {
    if (r && r.status === 200) {
      const copia = r.clone();
      caches.open(CACHE).then(c => c.put(clave, copia)).catch(() => {});
    }
    return r;
  });

  // La página: red primero, copia guardada solo si falla la red.
  if (esPagina) {
    e.respondWith(desdeRed().catch(() => caches.match(clave)));
    return;
  }

  // Assets: copia guardada primero, y se refresca por detrás.
  e.respondWith(
    caches.match(clave).then(guardado => {
      if (guardado) {
        desdeRed().catch(() => {});
        return guardado;
      }
      return desdeRed().catch(() => caches.match(req));
    })
  );
});
